import React from 'react';
import logo from './logo.svg';
import './App.css';
import Piano from './components/Piano'

function App() {
  return (
    <>
      <h1>Play your piano</h1>
      <Piano/>
    </>
  );
}

export default App;
